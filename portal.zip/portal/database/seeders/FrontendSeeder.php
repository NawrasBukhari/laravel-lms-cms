<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;


class FrontendSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('frontends')->delete();

        $frontend_data = [
            ['hero_title' => 'Go and change everything from the admin panel <3'],
        ];
        DB::table('frontends')->insert($frontend_data);
    }
}
