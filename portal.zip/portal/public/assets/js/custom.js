document.addEventListener('DOMContentLoaded', function() {

    $('.date-pick').datepicker();

});

